# Glass Box AI — Dataverse Schema (9 tables)

> Source of truth for all 9 Dataverse tables. Mirrors the Confluence Schema page
> (PM/1802251) and the GitHub repo. Pairs with `docs/schema/glassbox_schema.csv`
> and the ER diagram (`docs/diagrams/03_er_diagram.drawio`).

Every custom column carries the publisher prefix `gbx` (e.g. `gbx_claim_id`); the
clean logical names below are what users see in forms, Power BI, and exports.

## Design philosophy — slim schema + JSON
The `Claim` table holds **universal columns** plus one `loss_type_details`
Multiline-text(JSON) column. All loss-type-specific answers live as JSON inside
that column — avoiding 60+ flattened columns across 11 loss types.

## Data flow
Dataverse is the source of truth for the agent layer — every agent reads/writes
Dataverse only. Legacy core systems (Guidewire PolicyCenter or equivalent) hold
the enterprise system-of-record; ADF event-triggered pipelines sync into Dataverse
(<5 min latency). `Decision_Rationale` (Glass Box audit) lives in Dataverse **only**
— never pushed to legacy. Two claim numbers per claim: `gbx_claim_id` (shown to the
customer) and `gbx_legacy_claim_id` (assigned by the legacy core after ADF push).

## Tables

| # | Table | Category | Cols | Purpose |
|---|---|---|---|---|
| 1 | Policy | Core | 14 | Customer's insurance policy (synced from legacy) |
| 2 | Claim | Core (hub) | 35 | Central entity. Created at FNOL, updated by every agent, reverse-synced to legacy |
| 3 | Document | Core | 12 | Uploaded files; extracted data as JSON |
| 4 | Communication | Core | 11 | In/out messages per channel incl. delivery_status |
| 5 | Decision_Rationale | Audit / compliance | 15 | Glass Box audit log — every AI step writes one row |
| 6 | Adjuster | Pool (handlers) | 11 | Carrier employee pool — used by Handler Assignment Engine |
| 7 | Vendor | Pool (3rd parties) | 15 | DRP shops, towing, glass, rental, salvage — used by Vendor Assignment Engine |
| 8 | ClaimVendorAssignment | Join + audit | 11 | Many-to-many Claim↔Vendor with score + reason |
| 9 | StateRule | Reference (lookup) | 10 | 1 row per US state + DC — closure deadlines, comparative negligence, no-fault, glass waiver |

## 1. Policy
`id` (PK, `POL-{YYYY}-{####}`) · holder_name · holder_email · holder_phone ·
policy_type (Auto) · state (looks up StateRule) · coverage_details (`100/300/50`
shorthand) · total_limit · deductible · start_date · end_date · status
(Active/Lapsed/Cancelled/Pending) · policy_pdf_url (Blob, indexed by AI Search) · vin.

## 2. Claim — the core hub table
`id` (PK, `CLM-{YYYY}-{####}`, shown to customer) · policy_id (→Policy) ·
parent_claim_id (→Claim, **Reopen**) · assigned_adjuster_id (→Adjuster, set by
Handler Assignment Engine) · channel (MobileApp/Web/Teams/Email/SMS) · loss_type
(11 types) · sub_type · incident_date · incident_state (drives no-fault routing) ·
location · description (fed to LLM + sentiment) · **loss_type_details (JSON)** · vin ·
police_report_number · responding_agency · injury_flag · distress_flag (sentiment) ·
vehicle_drivable · vehicle_towed · tow_location · other_party_involved · status
(New/Processing/PendingIncomplete/AwaitingDocs/UnderReview/Approved/Denied/Escalated/
Suspended/Cancelled/Closed/**Reopen**) · confidence_score (0-100) · recommendation
(Approve/Deny/Partial/Escalate/Adjust) · settlement_amount · settlement_type
(DRP/Cash/TotalLoss/DirectToThirdParty) · tier (1/2/3) · assignment_reason ·
assigned_at · sla_due_at · resolved_at · docs_outstanding · manual_contact_flag ·
chase_day_count · legacy_claim_id.

## 3. Document
`id` (PK, `DOC-{YYYY}-{#####}`) · claim_id (→Claim) · doc_type (13 types: DamagePhoto,
DriversLicense, InsuranceCard, VehicleTitle, RegistrationCard, RepairEstimate,
PoliceReport, FireDeptReport, MedicalRecord, LostWagesLetter, ContractorEstimate,
WitnessStatement, Other) · file_name · file_url (Blob) · mime_type · size_bytes ·
extracted_data (JSON, Doc Intelligence) · quality_score (GPT-4o Vision) ·
missing_fields (JSON) · upload_date · channel.

## 4. Communication
`id` (PK, `COM-{YYYY}-{######}`) · claim_id (→Claim) · direction (Inbound/Outbound) ·
channel · message_content · attachments (JSON) · timestamp · agent_name ·
sentiment_score (-1 to 1) · sender_id · delivery_status (Sent/Delivered/Read/Failed/Bounced).

## 5. Decision_Rationale (the Glass Box) — regulatory artifact
Every agent action writes one row. The compliance artifact for **Colorado SB21-169 /
NAIC AI Model Bulletin / NY DFS Circular Letter No. 7**.
`id` (PK, `LOG-{YYYY}-{#######}`) · claim_id (→Claim) · agent_name (Intake/IntakeGate/
Extraction/Policy/Validation/Adjudication/Explanation/Notification/Adjuster/
AssignmentEngine/VendorEngine) · sub_agent (NOAA/NHTSA/ISO/NICB/DMV/Telematics/
EstimateRule/Sentiment) · action · policy_reference · data_points (JSON) ·
confidence_contribution (-1 to +1) · external_api_result (JSON) · adapter_status
(Live/Sandbox/NotApplicable) · flag_raised · flag_severity (Low/Medium/High) ·
**human_readable_explanation** (the compliance text) · latency_ms · timestamp.

## 6. Adjuster — handler pool
`id` (PK, `ADJ-{####}`) · aad_email (Entra ID SSO identity) · display_name ·
seniority (Junior/Senior/Lead) · skills (Auto-Collision/Comprehensive/Liability/BI/
PIP/UM-Specialist/SIU-Fraud) · state_licenses (must match claim incident_state) ·
is_available · max_workload_per_day · current_workload · timezone · excluded_policy_ids.

## 7. Vendor — 3rd-party providers
`id` (PK, `VND-{#####}`) · vendor_type (DRPShop/TowingCompany/GlassShop/RentalPartner/
SalvageYard/IndependentAppraiser/MedicalProvider) · name · address · latitude ·
longitude · service_radius_miles · services_offered · is_active_in_drp ·
customer_rating · drp_performance_score · current_capacity · phone · email · states_served.

## 8. ClaimVendorAssignment — join table
`id` (PK, `CVA-{######}`) · claim_id (→Claim) · vendor_id (→Vendor) · assignment_purpose
(Repair/Tow/Glass/Rental/Salvage/Inspect/Medical) · distance_miles · score (0-100) ·
assignment_reason (plain-English, for audit) · assigned_at · sla_due_at · status
(Notified/Accepted/InProgress/Completed/Cancelled/Declined) · completion_notes.

## 9. StateRule — reference table (51 rows: 50 states + DC)
State rules are **data, not code** — a rule change is a row update, no redeploy.
`id` (PK, `SR-{###}`) · state · closure_deadline_days · is_no_fault (FL/NY/NJ/MI/PA/
KY/KS/ND/HI/UT/OR/MA) · comparative_negligence_rule (Pure/Modified50/Modified51/
Contributory) · um_grace_period_days · policy_lapse_grace_days · total_loss_threshold_pct
· acknowledgment_deadline_days · glass_zero_deductible (FL/KY/KS/MA/SC/MN waive).

## Relationships
- Policy (1) → owns → Claim (many)
- Claim (1) → parent → Claim (many) [Reopen]
- Claim (1) → has → Document / Communication / Decision_Rationale (many)
- Adjuster (1) → handles → Claim (many) [Handler assignment]
- Claim (1) → ClaimVendorAssignment (many) ← Vendor (1) [Vendor assignment join]
- Policy / Claim → lookup by state → StateRule (by-value, not enforced FK)

## Build order (Day 1 of build window)
Custom publisher (`gbx`) → Solution "Glass Box AI" → tables in FK-safe order
(StateRule, Policy, Adjuster, Vendor, Claim, Document, Communication,
Decision_Rationale, ClaimVendorAssignment) → seed data (51 StateRule rows, 5
policies, 6-10 adjusters, 15-25 vendors) → verify Advanced Find → publish all.
