# Glass Box AI — Microsoft Resource Verification Guide

> **For the evaluation panel.** Everything below is real and independently checkable.
> This guide shows *exactly* where each Microsoft/Azure resource lives, how to open it,
> and how it maps to what you see in the demo. Carrier brand in the demo: **AI Elites**;
> the product is **Glass Box AI**.

There are three ways to verify, in increasing order of access needed:

1. **No login at all** → the live endpoints in §1 (anyone, any browser).
2. **The demo screen-share** → we open each portal below live on request.
3. **Tenant/subscription access** → use the deep-link paths in §2–§5.

---

## 0. Where everything lives (context)

| Scope | Value |
|---|---|
| Azure subscription | **Sandbox AI DS - 1003787** · `b9e3346a-95f9-4891-b24b-78528547f9a2` |
| Azure tenant | `3670e846-58dd-4658-86fb-00e4029045d6` |
| Azure resource group | **`rg-glassbox`** (East US 2) |
| Power Platform environment | **GlassBox-Dev** · Dataverse `https://orgc0207390.crm.dynamics.com` |

Azure resources: **https://portal.azure.com** → Resource groups → **rg-glassbox**
Power Platform: **https://make.powerapps.com** / **https://copilotstudio.microsoft.com** (env = GlassBox-Dev)

---

## 1. Verify with NO login — the live system

These are public; open them in any browser right now.

| Check | URL | What you should see |
|---|---|---|
| Live app | https://glassbox-fn-1003787.azurewebsites.net | The running Glass Box AI app (customer + handler) |
| Pitch deck | https://glassbox-fn-1003787.azurewebsites.net/present.html | The 11-slide deck |
| Health probe | https://glassbox-fn-1003787.azurewebsites.net/api/health | `{"ok":true,"email":"azure",...}` — confirms the backend + ACS email are live |
| Live claims (Dataverse) | https://glassbox-fn-1003787.azurewebsites.net/api/dv/claims | Real claim records served from Dataverse via managed identity |
| Source code | https://github.com/Sameet1308/Hack2future | Full frontend + Node API + setup scripts |

> `/api/dv/claims` returning real claims proves the hosted app authenticates to Dataverse
> with a **managed identity** (no secrets) and reads live data — not mock JSON.

---

## 2. Azure Portal — the 13 cloud resources (`rg-glassbox`)

Open the group: `https://portal.azure.com/#@/resource/subscriptions/b9e3346a-95f9-4891-b24b-78528547f9a2/resourceGroups/rg-glassbox/overview`

| Resource | Azure type | What it powers in the demo |
|---|---|---|
| **glassbox-aoai-1003787** | `Microsoft.CognitiveServices/accounts` (Azure OpenAI) | GPT-4.1 — **photo damage assessment (vision)**, policy Q&A, adjudication. Deployment name `gpt-4.1` |
| **glassbox-docintel** | `Microsoft.CognitiveServices/accounts` (Document Intelligence) | Document/evidence extraction (provisioned) |
| **glassbox-search-1003787** | `Microsoft.Search/searchServices` | **Azure AI Search** — RAG over policy + police-report docs (index `gbx-policy-docs`). Powers "Ask the policy · AI" |
| **glassbox-acs** | `Microsoft.Communication/CommunicationServices` | **Azure Communication Services** — sends the real claim / adjuster / settlement emails |
| **glassbox-email** + **/AzureManagedDomain** | `Microsoft.Communication/EmailServices` (+ Domain) | The verified sender domain for those emails |
| **glassbox-fn-1003787** | `Microsoft.Web/sites` (Function App) | **Hosts the whole app** (SPA + API) via a custom handler |
| **glassbox-fn-1003787** | `Microsoft.Insights/components` (App Insights) | Telemetry / monitoring for the Function |
| **EastUS2Plan** | `Microsoft.Web/serverFarms` | The hosting plan for the Function |
| **glassboxsa1003787** | `Microsoft.Storage/storageAccounts` | Functions runtime storage |
| **glassbox-web** | `Microsoft.Web/staticSites` | Azure Static Web App (alternate hosting target) |
| **Failure Anomalies …** / **App Insights Smart Detection** | alerts / action group | Automatic anomaly alerting on the Function |

**To confirm the AI is real:** open **glassbox-aoai-1003787 → Model deployments** → you'll see the `gpt-4.1` deployment; **Monitoring → Metrics** shows live token usage spiking when a demo photo is analyzed.
**To confirm AI Search:** open **glassbox-search-1003787 → Indexes** → index **`gbx-policy-docs`** with the policy documents.
**To confirm email:** open **glassbox-acs / glassbox-email** → the managed domain status is *Verified*.

CLI cross-check (anyone with read access):
```bash
az resource list -g rg-glassbox -o table
```

---

## 3. Copilot Studio — the conversational agent (Sara)

**https://copilotstudio.microsoft.com** → environment **GlassBox-Dev**

| What | Where to look | What it is |
|---|---|---|
| Agent | **Glass Box Claims Assistant** (persona **"Sara"**, GPT-4.1) | The customer-facing intake agent embedded in the app at `/customer/chat` |
| Topics | Agent → **Topics** | **Greeting** (proactive "Sara speaks first"), **FNOL_Start** (collision/comprehensive intake) |
| Knowledge / Tools | Agent → **Knowledge** & **Tools** | Dataverse Policy table as knowledge; calls the flows in §4 |
| Channels | Agent → **Channels → Web app** | The published embed URL used by our React app |

In the demo, when Sara collects the loss details and returns a real claim number, she is calling the **GlassBox-CreateClaim** flow (next section), which writes to Dataverse.

---

## 4. Power Automate — the flows (the "service layer")

**https://make.powerautomate.com** → environment **GlassBox-Dev** → **My flows** (also visible under the agent's Tools)

| Flow | What it does | Verify by |
|---|---|---|
| **GlassBox-GetPolicy** | Looks up a policy (coverage, deductible, status) from Dataverse | Run history shows lookups (e.g. Sarah Chen / POL-2026-0847) |
| **GlassBox-CreateClaim** | Creates the real claim record in Dataverse from the chat | Each demo claim = one successful run |
| **GlassBox-LogDecision** | Writes a plain-English **Decision Rationale** (audit) row per agent step | One run per logged decision |
| **GlassBox-GetClaimAudit** | Returns a claim's full audit trail (drives the Live Console) | HTTP GET flow; returns the audit JSON |
| **GlassBox-MasterOrchestration** | Fan-out pipeline that runs the downstream agents | Run history per processed claim |
| **GlassBox-Sandbox** | Sandbox adapters for external feeds (ISO/NICB/CARFAX/DMV/KBB/telematics) | Returns mocked-but-production-shaped responses |

Open any flow → **Run history** → click a run to see the exact inputs/outputs and Dataverse calls for a specific claim.

---

## 5. Dataverse — the data + the audit trail (the "Glass Box")

**https://make.powerapps.com** → environment **GlassBox-Dev** → **Tables** (or **Dataverse → Tables**).

The 9 tables behind the system:

| Table (display) | Logical name | Holds |
|---|---|---|
| Policy | `crcce_policy` | Policies (5 sample policyholders incl. Sarah Chen / POL-2026-0847) |
| **Claim** | `gbx_claim` | **Every claim** — number, loss type, VIN, status, confidence, settlement, tier |
| Document | `gbx_document` | Uploaded evidence (damage photos, police report, ID, estimate) |
| Communication | `gbx_communication` | Emails / notifications sent |
| **Decision Rationale** | `gbx_decisionrationale` | **The audit trail** — one plain-English row per agent decision |
| Adjuster | `gbx_adjuster` | Claim handlers |
| Vendor | `gbx_vendor` | Repair / appraisal vendors |
| Claim Vendor Assignment | `gbx_claimvendorassignment` | Vendor↔claim links |
| State Rule | `gbx_staterule` | Per-state regulatory rules |

**The single most convincing cross-check:**
1. Note the claim number shown in the demo (e.g. `CLM-2026-…`).
2. Open the **Claim** table → find that exact row with its real data.
3. Open the **Decision Rationale** table → filter to that claim → read the step-by-step,
   plain-English reasoning for **every** agent action (Intake → Extraction → Policy →
   Validation → Adjudication), each with a timestamp, agent name, and confidence.

That is the "Glass Box" — the same audit you can replay in the app's **Live Decision Console**
(`/handler/theater/<claim>`) is sitting in Dataverse as queryable rows.

---

## 6. Demo moment → resource that powered it

| In the demo you see… | Powered by | Verify in |
|---|---|---|
| Sara chatting, collecting the loss | Copilot Studio agent + GlassBox-CreateClaim | §3, §4 |
| "Your photo shows rear-end damage…" | Azure OpenAI GPT-4.1 vision | §2 (glassbox-aoai) |
| "Ask the policy" answered with a citation | Azure AI Search RAG | §2 (glassbox-search) |
| Claim appears in the adjuster queue | gbx_claim (Dataverse) | §5 |
| The step-by-step agent reasoning | gbx_decisionrationale (Dataverse) | §5 |
| Email lands in the inbox | Azure Communication Services | §2 (glassbox-acs) |
| The whole thing on a live URL | Azure Function (custom handler) | §1, §2 |

---

*All policyholder data is synthetic. Resource identifiers above are environment locators, not
secrets — they cannot be used without authenticated access to the tenant/subscription.*
